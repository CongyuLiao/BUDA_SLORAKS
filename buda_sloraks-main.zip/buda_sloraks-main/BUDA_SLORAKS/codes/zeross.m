function [ res ] = zeross( N )
%ZEROSS Summary of this function goes here
%   Detailed explanation goes here


res = zeros(N, 'single');

end

