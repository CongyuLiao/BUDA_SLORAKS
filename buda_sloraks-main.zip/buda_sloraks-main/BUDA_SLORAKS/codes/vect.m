function b = vec( a )
%VEC Summary of this function goes here
%   Detailed explanation goes here

    b = a(:);
end

