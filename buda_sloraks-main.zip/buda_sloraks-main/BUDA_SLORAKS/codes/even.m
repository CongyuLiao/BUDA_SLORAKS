function result = even(int)
result = not(rem(int,2));
end
